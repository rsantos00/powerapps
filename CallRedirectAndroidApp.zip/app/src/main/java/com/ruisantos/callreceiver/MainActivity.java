package com.ruisantos.callreceiver;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import android.widget.Toolbar;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    public static final int MY_PERMISSIONS_REQUEST_READ_PHONE_STATE = 0;
    public static final int MY_PERMISSIONS_REQUEST_PROCESS_OUTGOING_CALLS = 1;
    public static final int MY_PERMISSIONS_REQUEST_READ_CALL_LOG = 2;
    public static final String MY_PREFS_NAME = "PowerAppsRedirectFile";

    public static String PowerAppUrl="https://apps.powerapps.com/play/e05f9def-b83e-4c71-80ac-7aa7f0d686b5?tenantId=c6e281bb-48e9-41a6-8217-04b6bfb53bb0";

    CallReceiver callReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
            // We do not have this permission. Let's ask the user
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_PHONE_STATE},
                    MY_PERMISSIONS_REQUEST_READ_PHONE_STATE);
        }

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.READ_CALL_LOG)
                != PackageManager.PERMISSION_GRANTED) {
            // We do not have this permission. Let's ask the user
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_CALL_LOG},
                    MY_PERMISSIONS_REQUEST_READ_CALL_LOG);
        }

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.PROCESS_OUTGOING_CALLS)
                != PackageManager.PERMISSION_GRANTED) {
            // We do not have this permission. Let's ask the user
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.PROCESS_OUTGOING_CALLS},
                    MY_PERMISSIONS_REQUEST_PROCESS_OUTGOING_CALLS);
        }

        if (callReceiver == null) {
            callReceiver = new CallReceiver(this);
        }
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.PHONE_STATE");
        intentFilter.addAction("android.intent.action.NEW_OUTGOING_CALL");
        intentFilter.addAction("android.intent.action.READ_CALL_LOG");
        // dynamically register CallReceiver
        registerReceiver(callReceiver, intentFilter);


        ImageButton img = (ImageButton)findViewById(R.id.savePreferences);

        img.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                EditText url = (EditText)findViewById(R.id.editText2);
                editor.putString("powerappurl", url.getText().toString());
                editor.apply();
                editor.commit(); // commit changes
                Toast.makeText(getApplicationContext(), "Saved url", Toast.LENGTH_SHORT).show();
            }
        });
        EditText url = (EditText)findViewById(R.id.editText2);
        SharedPreferences pref = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        url.setText(pref.getString("powerappurl",null));
        if(!url.getText().toString().isEmpty())
            PowerAppUrl = url.getText().toString();
        else
        {
            url.setText(PowerAppUrl);
            SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
            editor.putString("powerappurl", PowerAppUrl);
            editor.apply();
            editor.commit(); // commit changes
        }
        url.setText(PowerAppUrl);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_PHONE_STATE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission granted!
                    // check PROCESS_OUTGOING_CALLS permission only when READ_PHONE_STATE is granted
                    if (ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.PROCESS_OUTGOING_CALLS)
                            != PackageManager.PERMISSION_GRANTED) {
                        // We do not have this permission. Let's ask the user
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.PROCESS_OUTGOING_CALLS},
                                MY_PERMISSIONS_REQUEST_PROCESS_OUTGOING_CALLS);
                    }
                } else {
                    // permission denied or has been cancelled
                    Toast.makeText(getApplicationContext(),
                            "READ_PHONE_STATE permission missing!",
                            Toast.LENGTH_LONG).show();
                }
                break;
            }
            case MY_PERMISSIONS_REQUEST_PROCESS_OUTGOING_CALLS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission granted!
                    Log.d("#", "Permissions granted!");
                } else {
                    // permission denied or has been cancelled
                    Toast.makeText(getApplicationContext(),
                            "PROCESS_OUTGOING_CALLS permission missing!",
                            Toast.LENGTH_LONG).show();
                }

                break;
            }
            case MY_PERMISSIONS_REQUEST_READ_CALL_LOG: {
                    if (grantResults.length > 0
                            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        // permission granted!
                        Log.d("#", "Permissions granted!");
                    } else {
                        // permission denied or has been cancelled
                        Toast.makeText(getApplicationContext(),
                                "PROCESS_OUTGOING_CALLS permission missing!",
                                Toast.LENGTH_LONG).show();
                    }
                    break;
                }
        }
    }


    public void NotifyNewCall(Context ctx,String phoneNumber)
    {
        TextView tv1 = (TextView)findViewById(R.id.globalMsg);
        tv1.setText(phoneNumber);

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(PowerAppUrl+"&phoneNumber="+phoneNumber));
        startActivity(browserIntent);

        String msg="This phone number was found in CRM";
        Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_LONG).show();

    }

    public void NotifyEndCall(Context ctx,String phoneNumber)
    {
        TextView tv1 = (TextView)findViewById(R.id.globalMsg);
        tv1.setText("Waiting for call");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // manually unregister dynamically registered CallReceiver
        if (callReceiver != null) {
            unregisterReceiver(callReceiver);
            callReceiver = null;
        }
    }
}

