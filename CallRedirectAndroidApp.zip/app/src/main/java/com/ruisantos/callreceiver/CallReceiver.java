package com.ruisantos.callreceiver;
import android.content.Context;
import android.widget.Toast;
import java.util.Date;

public class CallReceiver extends PhonecallReceiver {

    private MainActivity activity;

    public CallReceiver(MainActivity _activity)
    {
        this.activity=_activity;

    }
    @Override
    protected void onIncomingCallReceived(Context ctx, String number, Date start) {

        if(number != null)
        {
            String msg = "start incoming call: " + number + " at " + start;
            Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            this.activity.NotifyNewCall(ctx,number);
        }
    }

    @Override
    protected void onIncomingCallAnswered(Context ctx, String number, Date start) {
        /*String msg = "start incoming call: " + number + " at " + start;
        Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        Log.d("#", msg);*/
    }

    @Override
    protected void onOutgoingCallStarted(Context ctx, String number, Date start) {
       /* String msg = "start outgoing call: " + number + " at " + start;
        Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        Log.d("#", msg);
        */
       // webView.loadUrl("javascript:writeNumber('" + number + "')");
    }

    @Override
    protected void onIncomingCallEnded(Context ctx, String number, Date start, Date end) {
        String msg = "end incoming call: " + number + " at " + end;
        Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        //Log.d("#", msg);

        this.activity.NotifyEndCall(ctx,number);
    }

    @Override
    protected void onOutgoingCallEnded(Context ctx, String number, Date start, Date end) {
       /* String msg = "end outgoing call: " + number + " at " + end;
        Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        Log.d("#", msg); */
    }

    @Override
    protected void onMissedCall(Context ctx, String number, Date start) {
       /* String msg = "missed call: " + number + " at " + start;
        Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        Log.d("#", msg);
        */
    }
}