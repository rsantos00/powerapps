using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using QRCoder;
using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.ServiceModel;
using static QRCoder.PayloadGenerator;
using static QRCoder.QRCodeGenerator;

namespace PlugInQRCode
{
    /// <summary>
    /// Plugin development guide: https://docs.microsoft.com/powerapps/developer/common-data-service/plug-ins
    /// Best practices and guidance: https://docs.microsoft.com/powerapps/developer/common-data-service/best-practices/business-logic/
    /// </summary>
    public class GenerateQRCode : IPlugin

    {


        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                if (context.InputParameters.Contains("cat_QRCodeContent") && context.InputParameters["cat_QRCodeContent"] != null)
                {
                    tracingService.Trace("GenerateQRCode: {0}", "Enter 1");
                    string dataRequest = "na";
                    context.InputParameters.TryGetValue("cat_QRCodeContent", out dataRequest);
                    tracingService.Trace("GenerateQRCode: {0}", "Type:" + dataRequest);
                                        
                    QRCodeGenerator qrGenerator = new QRCodeGenerator();

                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(dataRequest, ECCLevel.Q);

                    Base64QRCode qrCode = new Base64QRCode(qrCodeData);
                    string qrCodeImageAsBase64 = qrCode.GetGraphic(5, Color.Black, Color.White, true, Base64QRCode.ImageType.Png);

                    context.OutputParameters["cat_Base64QrCode"] = qrCodeImageAsBase64;


                }
                tracingService.Trace("GenerateQRCode: {0}", "End ");

                // Obtain the execution context from the service provider.  
                
                
                
                

            }            
            catch (Exception ex)
            {
                tracingService.Trace("GenerateQRCode: {0}", ex.ToString());
                throw;
            }

            
        }
    }
}
