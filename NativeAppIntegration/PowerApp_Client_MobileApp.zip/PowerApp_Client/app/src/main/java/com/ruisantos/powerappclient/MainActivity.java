package com.ruisantos.powerappclient;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.provider.SyncStateContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import android.widget.Toolbar;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {

    public static final String MY_PREFS_NAME = "PowerAppsClientFile";
    private CheckBox checkBox;
    private NfcAdapter mNfcAdapter;
    public static final String TAG = MainActivity.class.getSimpleName();
    private EditText mEtMessage;
    private Button mBtWrite;
    private Button mBtRead;
    private WebView wv;
    private ArrayList<String> mDeviceList = new ArrayList<String>();
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private UUID uuid= UUID.fromString("34B1CF4D-1069-4AD6-89B6-E161D79BE4D8");

    public static String PowerAppUrl="https://apps.powerapps.com/play/92bcee04-9592-4f99-9226-927fed9cc26c?tenantId=c6e281bb-48e9-41a6-8217-04b6bfb53bb0";


    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;

    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE = 2;
    private static final int REQUEST_ENABLE_BT = 3;

    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the chat services
    private BluetoothChatService mChatService = null;

    // Name of the connected device
    private String mConnectedDeviceName = null;
    // Array adapter for the conversation thread
    private ArrayAdapter<String> mConversationArrayAdapter;
    // String buffer for outgoing messages
    private StringBuffer mOutStringBuffer;
    private Boolean IsCoonected=false;

    BluetoothAdapter.LeScanCallback mLeScanCallback=null;
    BluetoothLeScanner scannerLe;

    //    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        checkBox=  (CheckBox) findViewById(R.id.checkBox);

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    FrameLayout frameLayout = (FrameLayout) findViewById(R.id.WebViewFrame);
                    frameLayout.setVisibility(View.INVISIBLE);

                    LinearLayout linearLayout = (LinearLayout) findViewById(R.id.configurationScreen);
                    linearLayout.setVisibility(View.VISIBLE);
                }
                else
                {
                    FrameLayout frameLayout = (FrameLayout) findViewById(R.id.WebViewFrame);
                    frameLayout.setVisibility(View.VISIBLE);

                    LinearLayout linearLayout = (LinearLayout) findViewById(R.id.configurationScreen);
                    linearLayout.setVisibility(View.INVISIBLE);

                    SharedPreferences pref = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

                    String site= pref.getString("powerappurl",null);
                    wv = (WebView) findViewById(R.id.webview);
                    configureWebView(PowerAppUrl);
                }

            }
        });


        ImageButton img = (ImageButton)findViewById(R.id.savePreferences);

        img.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                EditText url = (EditText)findViewById(R.id.editText2);
                editor.putString("powerappurl", url.getText().toString());
                editor.apply();
                editor.commit(); // commit changes
                Toast.makeText(getApplicationContext(), "Saved url", Toast.LENGTH_SHORT).show();
            }
        });
        EditText url = (EditText)findViewById(R.id.editText2);
        SharedPreferences pref = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        url.setText(pref.getString("powerappurl",null));
        if(!url.getText().toString().isEmpty())
        {
            PowerAppUrl = url.getText().toString();
            wv = (WebView) findViewById(R.id.webview);
            wv.clearCache(true);
            configureWebView(PowerAppUrl);
        }
        else
        {
            url.setText(PowerAppUrl);
            SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
            editor.putString("powerappurl", PowerAppUrl);
            editor.apply();
            editor.commit(); // commit changes
        }
        url.setText(PowerAppUrl);
        initNFC();

        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                MY_PERMISSIONS_REQUEST_LOCATION);

        //mInterface.requestPermission(Manifest.permission.ACCESS_COARSE_LOCATION, mCoarsePermissionTag);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        mBluetoothAdapter.startDiscovery();


        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothDevice.EXTRA_UUID);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(mReceiver, filter);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }
    }


    @Override
    public void onStart() {
        super.onStart();

        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(
                    BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
            // Otherwise, setup the chat session
        } else {
            if (mChatService == null)
                setupChat();
        }
    }

    private void setupChat() {

        // Initialize the BluetoothChatService to perform bluetooth connections
        mChatService = new BluetoothChatService(this, mHandler);

        // Initialize the buffer for outgoing messages
        mOutStringBuffer = new StringBuffer("");
    }

    private void ensureDiscoverable() {
        if (mBluetoothAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(
                    BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(
                    BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(discoverableIntent);
        }
    }

    private void sendMessage(String message) {
        // Check that we're actually connected before trying anything
        if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED) {
            Toast.makeText(this, "Not connected", Toast.LENGTH_SHORT)
                    .show();
            return;
        }

        // Check that there's actually something to send
        if (message.length() > 0) {
            // Get the message bytes and tell the BluetoothChatService to write
            byte[] send = message.getBytes();
            mChatService.write(send);
            // Reset out string buffer to zero and clear the edit text field
            mOutStringBuffer.setLength(0);
        }
    }


    public void refreshBluetooth()
    {
        mDeviceList.clear();
        if (!mBluetoothAdapter.isEnabled()) {
            // We need to enable the Bluetooth, so we ask the user
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }

        // If we're already discovering, stop it
        if (mBluetoothAdapter.isDiscovering()) {
            mBluetoothAdapter.cancelDiscovery();
        }

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

        for(BluetoothDevice device : pairedDevices)
            mDeviceList.add(device.getName() + "--" + device.getAddress() + "--pair" );

        // Request discover from BluetoothAdapter
        mBluetoothAdapter.startDiscovery();

        if(mLeScanCallback == null)
        {
            mLeScanCallback = new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bytes) {
                    //mRecyclerViewAdapter.addDevice(bluetoothDevice.getAddress());
                    String deviceName= bluetoothDevice.getName();
                    Toast.makeText(getApplicationContext(), deviceName, Toast.LENGTH_SHORT).show();
                }
            };
        }
        if(scannerLe == null)
            scannerLe = mBluetoothAdapter.getBluetoothLeScanner();

        scannerLe.startScan((ScanCallback)mLeScanCallback);

    }

    /*public void refreshBluetooth()
    {
        if(mLeScanCallback == null)
        {
            mLeScanCallback = new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bytes) {
                    //mRecyclerViewAdapter.addDevice(bluetoothDevice.getAddress());
                    String deviceName= bluetoothDevice.getName();
                    Toast.makeText(getApplicationContext(), deviceName, Toast.LENGTH_SHORT).show();
                }
            };
        }
        if(scannerLe == null)
            scannerLe = mBluetoothAdapter.getBluetoothLeScanner();

        scannerLe.startScan((ScanCallback)mLeScanCallback);

    }*/


    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (context.checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != PackageManager.PERMISSION_GRANTED) {
                Log.i("BT", "Permission denied");
            }

            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                mDeviceList.add(device.getName() + "--" + device.getAddress()+"--Unkown");
                StringBuilder builder = new StringBuilder();
                builder.append("  ");
                for(String s : mDeviceList) {
                    builder.append(s+"|");
                }

                //Toast.makeText(getApplicationContext(), device.getName() + "\n" + device.getAddress(), Toast.LENGTH_LONG).show();

                wv.post(new MyRunnable(builder.toString()) {
                    @Override
                    public void run() {
                        CallJSFunctionBluetooth("NCFReceivedData",_query);
                    }
                });

               // CallJSFunction("NCFReceivedData","Done");
            }
        }
    };

    private void configureWebView(String url)
    {
        WebSettings webSettings = wv.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);

        WebViewClient c=null;
        wv.setWebViewClient(c=new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                    StringBuilder sb = new StringBuilder();
                    sb.append("var attached = false; function NCFReceivedData(source,text){ var o = document.getElementsByTagName('iframe')[0]; o.contentWindow.postMessage(text, '*');  }; ");

                    sb.append(" function callMe(text) { console.log(text); };  ");

                    //sb.append("window.ruiMessage = function(event) { callMe(event.data); if(event.data=='Scan')NFC.MessageFromPA(event.data); };");
                    sb.append("window.ruiMessage = function(event) { if(event.data.constructor === String && event.data.startsWith('mobile|')){callMe(event.data); NFC.MessageFromPA(event.data);} };");
                    sb.append("if(!attached){window.addEventListener(\"message\",window.ruiMessage);attached=true;}");
                    view.loadUrl("javascript:" + sb.toString());
                }
            }
        );

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
        } else {
            CookieManager.getInstance().setAcceptCookie(true);
        }

        wv.addJavascriptInterface(new Object()
        {
            //Called NFC.startNFC('hi there');
            @JavascriptInterface
            public void MessageFromPA(String query)
            {
                if(query.startsWith("mobile|"))
                {
                    //Message from PowerApps
                    String command = query.replace("mobile|","").substring(0,4);
                    String data = query.replace("mobile|","").substring(4);

                    Log.d("Phone",command+","+data);
                    Toast.makeText(getApplicationContext(), "Received command from PA", Toast.LENGTH_SHORT).show();

                    switch (command)
                    {
                        //Echo
                        case "0000":
                            wv.post(new MyRunnable(query) {
                                @Override
                                public void run() {
                                    CallJSFunctionBluetooth("NCFReceivedData","echo"+_query);
                                }
                            });

                        break;
                        //Scan bluetooth
                        case "0001":
                            refreshBluetooth();
                            break;

                        case "0002":
                            //AcceptMessage();
                            //start_accepting_connection();
                            break;

                        case "0003":
                            //SendMessageToBluetoothDevice("F0:6E:0B:C1:CA:1D");

                            connectDevice("F0:6E:0B:C1:CA:1D");

                            //mHandler.obtainMessage(REQUEST_CONNECT_DEVICE,"F0:6E:0B:C1:CA:1D").sendToTarget();


                            break;
                        case "0004":

                            mChatService.write(data.substring(1).getBytes());

                            //sendMessage(data);
                            //bluetooth_message=data;
                            //mHandler.obtainMessage(MESSAGE_WRITE,clientSocket).sendToTarget();

                            //SendMessageToBluetoothDevice("F0:6E:0B:C1:CA:1D");
                        default:
                        break;


                    }
                }

               // Toast.makeText(MainActivity.this, query, Toast.LENGTH_SHORT).show();

            }
        }, "NFC");

        wv.loadUrl(url);

    }

    private void CallJSFunction(String functionName, String functionParameters)
    {
        wv.evaluateJavascript(functionName+"('nfc','"+functionParameters+"');", null);
    }

    private void CallJSFunctionBluetooth(String functionName, String functionParameters)
    {
        wv.evaluateJavascript(functionName+"('bluetooth','bluetooth"+functionParameters+"');", null);
    }

    private void initNFC(){

        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mReceiver);
        if (mChatService != null)
            mChatService.stop();



    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        IntentFilter ndefDetected = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
        IntentFilter techDetected = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
        IntentFilter[] nfcIntentFilter = new IntentFilter[]{techDetected,tagDetected,ndefDetected};

        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        if(mNfcAdapter!= null)
            mNfcAdapter.enableForegroundDispatch(this, pendingIntent, nfcIntentFilter, null);

        if (mChatService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't
            // started already
            if (mChatService.getState() == BluetoothChatService.STATE_NONE) {
                // Start the Bluetooth chat services
                mChatService.start();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(mNfcAdapter!= null)
            mNfcAdapter.disableForegroundDispatch(this);
    }

    private String dumpTagData(Parcelable p) {
        StringBuilder sb = new StringBuilder();
        Tag tag = (Tag) p;
        byte[] id = tag.getId();
        // only show hex format id
        sb.append("tag").append(getHex(id));
        return sb.toString();

    }


    private String getHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            int b = bytes[i] & 0xff;
            if (b < 0x10)
                sb.append('0');
            sb.append(Integer.toHexString(b).toUpperCase());
            if (i > 0) {
                sb.append("");
            }
        }
        return sb.toString();
    }

    @Override
    protected void onNewIntent(Intent intent) {

        NdefMessage[] msgs;
        String action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action) || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action) || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action))
        {
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            byte[] empty = new byte[0];
            byte[] id = intent.getByteArrayExtra(NfcAdapter.EXTRA_ID);
            Parcelable tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            String tags = dumpTagData(tag);

            //Toast.makeText(getApplicationContext(), sss, Toast.LENGTH_LONG).show();

            CallJSFunction("NCFReceivedData",tags);
        }

    }

    public abstract class MyRunnable implements Runnable {
        String _query;
        MyRunnable(String s) { _query = s; }

    }

    public void ReceivedBluetoothMessage(byte[] message,int bytesNum)
    {
        String readMessage = new String(message,0,bytesNum);
        wv.post(new MyRunnable(readMessage) {
            @Override
            public void run() {
                CallJSFunctionBluetooth("NCFReceivedData",_query);
            }
        });

    }

    // The Handler that gets information back from the BluetoothChatService
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_STATE_CHANGE:

                    switch (msg.arg1) {
                        case BluetoothChatService.STATE_CONNECTED:
                            //mConversationArrayAdapter.clear();
                            break;
                        case BluetoothChatService.STATE_CONNECTING:
                            break;
                        case BluetoothChatService.STATE_LISTEN:
                        case BluetoothChatService.STATE_NONE:
                            break;
                    }
                    break;
                case MESSAGE_WRITE:
                    byte[] writeBuf = (byte[]) msg.obj;
                    // construct a string from the buffer
                    String writeMessage = new String(writeBuf);
                   // mConversationArrayAdapter.add("Me:  " + writeMessage);
                    break;
                case MESSAGE_READ:
                    byte[] readBuf = (byte[]) msg.obj;
                    // construct a string from the valid bytes in the buffer
                    String readMessage = new String(readBuf, 0, msg.arg1);
                    CallJSFunctionBluetooth("NCFReceivedData",readMessage);

                    break;
                case MESSAGE_DEVICE_NAME:
                    // save the connected device's name
                    mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                    Toast.makeText(getApplicationContext(),
                            "Connected to " + mConnectedDeviceName,
                            Toast.LENGTH_SHORT).show();
                    break;
                case MESSAGE_TOAST:
                    Toast.makeText(getApplicationContext(),
                            msg.getData().getString(TOAST), Toast.LENGTH_SHORT)
                            .show();
                    break;
            }
        }
    };

    private void connectDevice(String address) {
        if(!IsCoonected) {
            // Get the BluetoothDevice object
            BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
            // Attempt to connect to the device
            mChatService.connect(device);
            IsCoonected=true;
        }
    }

/*
    //private BluetoothSocket btSocket=null;
    private void SendMessageToBluetoothDevice(String deviceAddress) {

        mHandler.obtainMessage(MESSAGE_WRITE,clientSocket).sendToTarget();



    }


    public void start_accepting_connection()
    {
        //call this on button click as suited by you

        AcceptThread acceptThread = new AcceptThread();
        acceptThread.start();
        Toast.makeText(getApplicationContext(),"accepting",Toast.LENGTH_SHORT).show();
    }

    public void start_connecting(String deviceAddress)
    {
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceAddress);
        ConnectThread connectThread = new ConnectThread(device);
        connectThread.start();
        Toast.makeText(getApplicationContext(),"Connected",Toast.LENGTH_SHORT).show();
    }


    private void AcceptMessage()
    {
        mBluetoothAdapter=BluetoothAdapter.getDefaultAdapter();
        try {
            BluetoothServerSocket mBluetoothServerSocket=mBluetoothAdapter.listenUsingRfcommWithServiceRecord("BT_SERVER",uuid);
            //mBluetoothAdapter.cancelDiscovery();
            mBluetoothAdapter.setName("BT_Server");
            clientSocket=mBluetoothServerSocket.accept();
            InputStream mInputStream=clientSocket.getInputStream();

            BufferedReader mBufferedReader=new BufferedReader(new InputStreamReader(mInputStream));
            String data = mBufferedReader.readLine();

            while(mInputStream.available()>0){
                data +=mBufferedReader.readLine();
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }


    String bluetooth_message="00";


    @SuppressLint("HandlerLeak")
    Handler mHandler=new Handler()
    {
        @Override
        public void handleMessage(Message msg_type) {
            super.handleMessage(msg_type);

            switch (msg_type.what){
                case MESSAGE_READ:

                    byte[] readbuf=(byte[])msg_type.obj;
                    String string_recieved=new String(readbuf);

                    //do some task based on recieved string

                    break;
                case MESSAGE_WRITE:

                    if(msg_type.obj!=null){
                        ConnectedThread connectedThread=new ConnectedThread((BluetoothSocket)msg_type.obj);
                        connectedThread.write(bluetooth_message.getBytes());

                    }
                    break;

                case CONNECTED:
                    Toast.makeText(getApplicationContext(),"Connected",Toast.LENGTH_SHORT).show();
                    break;

                case CONNECTING:
                    Toast.makeText(getApplicationContext(),"Connecting...",Toast.LENGTH_SHORT).show();
                    break;

                case NO_SOCKET_FOUND:
                    Toast.makeText(getApplicationContext(),"No socket found",Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    private class AcceptThread extends Thread
    {
        private final BluetoothServerSocket serverSocket;

        public AcceptThread() {
            BluetoothServerSocket tmp = null;
            try {
                // MY_UUID is the app's UUID string, also used by the client code
                tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord("NAME",uuid);
            } catch (IOException e) { }
            serverSocket = tmp;
        }

        public void run() {
            BluetoothSocket socket = null;
            // Keep listening until exception occurs or a socket is returned
            while (true) {
                try {
                    socket = serverSocket.accept();
                } catch (IOException e) {
                    break;
                }

                // If a connection was accepted
                if (socket != null)
                {
                    // Do work to manage the connection (in a separate thread)
                    mHandler.obtainMessage(CONNECTED).sendToTarget();
                }
            }
        }
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;

        public ConnectThread(BluetoothDevice device) {
            // Use a temporary object that is later assigned to mmSocket,
            // because mmSocket is final
            BluetoothSocket tmp = null;
            mmDevice = device;

            // Get a BluetoothSocket to connect with the given BluetoothDevice
            try {
                // MY_UUID is the app's UUID string, also used by the server code
                tmp = device.createRfcommSocketToServiceRecord(uuid);
            } catch (IOException e) { }
            mmSocket = tmp;
        }

        public void run() {
            // Cancel discovery because it will slow down the connection
            mBluetoothAdapter.cancelDiscovery();

            try {
                // Connect the device through the socket. This will block
                // until it succeeds or throws an exception
                mHandler.obtainMessage(CONNECTING).sendToTarget();

                mmSocket.connect();
            } catch (IOException connectException) {
                // Unable to connect; close the socket and get out
                try {
                    mmSocket.close();
                } catch (IOException closeException) { }
                return;
            }

            // Do work to manage the connection (in a separate thread)
                bluetooth_message = "Initial message";
                mHandler.obtainMessage(MESSAGE_WRITE,mmSocket).sendToTarget();
                clientSocket=mmSocket;
        }


        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }

    private class ConnectedThread extends Thread {

        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[2];  // buffer store for the stream
            int bytes; // bytes returned from read()

            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);
                    // Send the obtained bytes to the UI activity
                    mHandler.obtainMessage(MESSAGE_READ, bytes, -1, buffer).sendToTarget();

                } catch (IOException e) {
                    break;
                }
            }
        }


        public void write(byte[] bytes) {
            try {
                mmOutStream.write(bytes);

                mmOutStream.close();

            } catch (IOException e) { }
        }


        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) { }
        }
    }*/

}

