var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./IFrameControl/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./IFrameControl/index.ts":
/*!********************************!*\
  !*** ./IFrameControl/index.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar IFrameControlV2 =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function IFrameControlV2() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  IFrameControlV2.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._context = context;\n    this._container = document.createElement(\"div\");\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._refreshData = this.refreshData.bind(this); // creating HTML elements for the input type range and binding it to the function which refreshes the control data\n    // <iframe src=\"demo_iframe.htm\" height=\"200\" width=\"300\"></iframe>\n\n    this.iframecontrol = document.createElement(\"iframe\");\n    this.iframecontrol.setAttribute(\"src\", context.parameters.IFrameLocation.raw ? context.parameters.IFrameLocation.raw : \"https://www.bing.com\");\n    this.iframecontrol.setAttribute(\"height\", context.parameters.IFrameLocation_Width.raw ? context.parameters.IFrameLocation_Width.raw : \"300\");\n    this.iframecontrol.setAttribute(\"width\", context.parameters.IFrameLocation_Height.raw ? context.parameters.IFrameLocation_Height.raw : \"300\");\n\n    this._container.appendChild(this.iframecontrol); //this._container.appendChild(this.labelElement);\n\n\n    container.appendChild(this._container);\n  }; //I shouldnt need this at all \n\n\n  IFrameControlV2.prototype.refreshData = function (evt) {\n    this._value = this.iframecontrol.getAttribute(\"src\");\n\n    this._notifyOutputChanged();\n  };\n\n  IFrameControlV2.prototype.updateView = function (context) {\n    //TODO: Check if this quick fix works\n    // storing the latest context from the control.\n    this._value = context.parameters.IFrameLocation.raw ? context.parameters.IFrameLocation.raw : \"https://www.bing.com\";\n    this._context = context;\n    this.iframecontrol.setAttribute(\"src\", context.parameters.IFrameLocation.raw ? context.parameters.IFrameLocation.raw : \"https://www.bing.com\");\n    this.iframecontrol.setAttribute(\"height\", context.parameters.IFrameLocation_Width.raw ? context.parameters.IFrameLocation_Width.raw : \"300\");\n    this.iframecontrol.setAttribute(\"width\", context.parameters.IFrameLocation_Height.raw ? context.parameters.IFrameLocation_Height.raw : \"300\"); //this.iframecontrol.innerHTML = context.parameters.sliderValue.formatted ? context.parameters.sliderValue.formatted : \"\";\n  };\n\n  IFrameControlV2.prototype.getOutputs = function () {\n    return {//sliderValue: this._value\n    };\n  };\n\n  IFrameControlV2.prototype.destroy = function () {//Dont need this\n    //this.iframecontrol.removeEventListener(\"input\", this._refreshData);\n  };\n\n  return IFrameControlV2;\n}();\n\nexports.IFrameControlV2 = IFrameControlV2;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./IFrameControl/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('iframeControlRuiSantos.IFrameControlV2', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IFrameControlV2);
} else {
	var iframeControlRuiSantos = iframeControlRuiSantos || {};
	iframeControlRuiSantos.IFrameControlV2 = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IFrameControlV2;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}